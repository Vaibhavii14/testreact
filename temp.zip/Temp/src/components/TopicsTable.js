/**
 * @license
 * Copyright &copy 2020 Cerner Corporation
 *
 * @author Vaibhavi Gosai
 */

import React, { Component} from 'react';  
import '../css/TopicsTable.css';
import Child from './NewComponent';

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

import CommentIcon from '@material-ui/icons/Comment';
import ThumbUpIcon from '@material-ui/icons/ThumbUp';
import ThumbDownAltIcon from '@material-ui/icons/ThumbDownAlt';
import { Collapse } from '@material-ui/core';


/**
 * createData defines a new data type to store the required data.
 * @param Topic - Can access the data passed to createdata using data.Topic while mapping
 * @param Tag -  Can access the data passed to createdata using data.Tag while mapping
 * @param Date -  Can access the data passed to createdata using as data.Date while mapping
 * @param Upvote -  Can access the data passed to createdata using as data.Upvote while mapping
 * @param Downvote -  Can access the data passed to createdata using as data.Downvote while mapping
 * @param Comment -   Can access the data passed to createdata using as data.Comment while mapping
 * @return returns the values in parameter
 */
function createData(Topic, Tag, Date, Upvote, Downvote,Comment ) {
  return { Topic, Tag, Date, Upvote, Downvote,Comment };
}

/**
 * constant to store dummy data of data type- createData
*/
const rows = [
  createData('How much loss of economy caused by COVID-19?', 'Sports Health',"02/12/2020", 9, 7, 3),
  createData('Every citizen should be mandated to perform national public service.', 'Tag2',"03/20/2020", 10, 2, 6),
  createData('Alternative energy resources should be explored.', 'Science' ,"02/12/2016", 6, 4, 0),
  createData('Topic 1', 'Tag1',"02/12/2020", 3, 7, 4),
  createData('Topic 2', 'Tag2 Tag3',"02/12/2020", 1, 4, 3),
  createData('Alternative energy resources should be explored.', 'Tag1',"02/12/2020", 3, 6, 3),
  createData('Topic 4', 'Tag2 Tag3',"12/12/2020", 1, 9, 9),
  createData('Topic 5', 'Tag1',"07/12/2015", 3, 7, 4),
  createData('Topic 6', 'Tag2 Tag3',"01/12/2020", 1, 4, 9),
  createData('Topic 7', 'Tag1',"02/12/2020", 3, 7, 3),
  createData('Topic 8', 'Tag2 Tag3',"02/12/2020", 0, 4, 3),
  createData('Topic 9', 'Tag1',"02/12/2020", 3, 6, 4),
  createData('Topic 10', 'Tag2 Tag3',"02/12/2020", 10, 9, 3),
  createData('Topic 11', 'Tag1',"02/12/2020", 7, 0, 1),
  createData('Topic 12', 'Tag2 Tag3',"02/12/2020", 1, 4, 9),
  createData('Topic 13', 'Tag1',"02/12/2020", 3, 4, 1),
  createData('Topic 14', 'Tag2 Tag3',"02/12/2020", 1, 4, 3),
  createData('Topic 15', 'Tag1',"02/12/2020", 7, 5, 3),
  createData('Topic 16', 'Tag2 Tag3',"02/12/2020", 1, 9, 3),
  createData('Topic 17', 'Tag1',"02/12/2020", 3, 6, 2),

];

/**
 * Generates a table using Material-UI Table component.
 * @returns {Table} table component
*/
class TopicsTable extends Component {


  constructor(){
    super();
    this.state={show:false,expandedRows : []}}
 
  handleClick(id){
    if (!this.state.expandedRows){
      this.state.expandedRows.concat(id);
    }else{
      this.state.expandedRows.filter(id1 => id1 !== id);
    }
    
    this.setState({
        show:!this.state.show
    })
    console.log('The link was clicked.');
  };
 

  render(){
    return (
        <Table  className="tablecss" aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell align="center" className="frozen"><h2><b>Topic</b></h2></TableCell>
              <TableCell align="center" ><h2><b>Tags</b></h2></TableCell>
              <TableCell align="center" ><h2><b>Date</b></h2></TableCell>
              <TableCell align="center" ><ThumbUpIcon style={{fill: "green"}}/></TableCell>
              <TableCell align="center" ><ThumbDownAltIcon style={{fill: "darkred"}}/></TableCell>
              <TableCell align="center" ><CommentIcon style={{fill: "darkblue"}}/></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
              {rows.map((row,index) => (
                <TableRow key={index} onClick={() => this.handleClick(index)} >
                  {/* <ExpansionPanel className="root">
                  <ExpansionPanelSummary aria-controls="panel1c-content" id="panel1c-header"
                  > */}
                    <TableCell align="left" className="frozen">
                      {/* <a  href="#" onClick={()=> {this.setState({show:!this.state.show})}}> */}
                                       
                      {row.Topic} 
                      {/* {this.state.show?<Child/>:null}    */}
                    </TableCell>
                    <TableCell align="center">{row.Tag}</TableCell>
                    <TableCell align="center">{row.Date}</TableCell>
                    <TableCell align="center">{row.Upvote}</TableCell>
                    <TableCell align="center">{row.Downvote}</TableCell>
                    <TableCell align="center">{row.Comment}</TableCell>
                    {/* </ExpansionPanelSummary>
                  <ExpansionPanelDetails>
                    <Child/>
                  </ExpansionPanelDetails>
                </ExpansionPanel> */}
                    {/* <Collapse hidden={!this.state.show && this.state.expandedRows.find(index)} in={this.state.show && this.state.expandedRows.find(index)}><Child/></Collapse> */}
                  <Collapse hidden={!this.state.show} in={this.state.show}><Child/></Collapse> */}
                
                </TableRow>
                 ))

                
               
              }
          </TableBody>
        </Table>
    );
  }
}


export default TopicsTable;