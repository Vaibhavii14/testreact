import React, { Component } from 'react';  
import '../css/TopicsTable.css';

class Child extends Component{
    render(){
      return(
          <div className="tablecss" align="center">
<p>Opened Yay!!<br/>I wanted to display comments for this TopicsTable<br/>Tag:: tag1</p>

          </div>
          );
    }
  }

  export default Child;