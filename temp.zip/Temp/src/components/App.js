import '../css/App.css';
import React, { Component } from 'react';  
import TopicsTable from './TopicsTable';

class App extends Component {  
  render() {
    return (
    <div className="App">
      <header className="App-header">
        <h2 className="hdr"><i>Openion</i></h2>
      </header>
      <TopicsTable/>
      <br/>
      <a className="Landing-Page">
          Openion - A crowd sourcing platform
        </a>
    </div>
  );
}}

export default App;
