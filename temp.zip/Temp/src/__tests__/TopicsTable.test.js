/**
 * @license
 * Copyright &copy 2020 Cerner Corporation
 *
 * @author Vaibhavi Gosai
 */

import React from 'react';
import TopicsTable from '../components/TopicsTable';
import renderer from 'react-test-renderer';

/**
 * Test that the page renders the TopicsTable in div
 */
describe("Table component", () => {
const TopicsTableComponent = renderer.create(<TopicsTable />).toJSON();
const child = TopicsTableComponent.children;
const trowforthead = child[0].children;
const trowfortbody = child[1].children;
const thforthead = trowforthead[0].children;
const tdfortbody = trowfortbody[0].children;

it('render correctly table component', () => {  
  expect(TopicsTableComponent).toMatchSnapshot();
});

it('correctly renders table i.e. <table/>', () => {  
  expect(TopicsTableComponent.type).toBe("table");
});

it('correctly renders table-head i.e. <thead/>', () => {  
  expect(child[0].type).toBe("thead");
});

it('correctly renders table-body i.e. <tbody/>', () => {  
  expect(child[1].type).toBe("tbody");
});

it('correctly renders to be table-head-s row i.e. <tr/>', () => {  
  expect(trowforthead[0].type).toBe("tr");
});

it('Correctly renders table-head to have 1 column', () => {  
  expect(trowforthead).toHaveLength(1);
});

it('render correctly null value as the thead rows does not have 2nd thead row <tr/>', () => {  
  expect(trowforthead[1]).toEqual();
});

it('correctly renders to be table-body-s row i.e. <tr/>', () => {  
  expect(trowfortbody[0].type).toBe("tr");
});

it('Correctly renders table-body to have 25 rows', () => {  
  expect(trowfortbody).toHaveLength(25);
});

it('render correctly null value as the tbody rows does not have 26th tbody row <tr/>', () => {  
  expect(trowfortbody[25]).toEqual();
});

it('correctly renders to be table-head-s column i.e. <th/>', () => {  
  expect(thforthead[0].type).toBe("th");
});

it('Correctly renders 6 table-body-s columns for each data entry i.e. <td/>', () => {  
  expect(tdfortbody[0].type).toBe("td");
});

});

